"use client"

/**
 * Cinematic, fully-synthesized audio engine using the Web Audio API.
 * No external URLs — everything is generated from oscillators + noise buffers.
 * Singleton: getAudioEngine().
 *
 * IMPORTANT: must be unlocked on a real user gesture. We expose `unlock()` and
 * `init()` for that purpose. Subsequent calls before unlock are no-ops.
 */

type Nullable<T> = T | null

class AudioEngine {
  private ctx: Nullable<AudioContext> = null
  private master: Nullable<GainNode> = null
  private unlocked = false

  // ---- per-effect handles
  private slideOsc: Nullable<OscillatorNode> = null
  private slideSubOsc: Nullable<OscillatorNode> = null
  private slideGain: Nullable<GainNode> = null

  private padMaster: Nullable<GainNode> = null
  private padNodes: { osc: OscillatorNode; gain: GainNode }[] = []
  private padLfo: Nullable<OscillatorNode> = null

  private thumpTimer: number | null = null
  private thumpGetProgress: (() => number) | null = null

  private fwTimer: number | null = null

  // ----------------------------------------------------------------
  // Lifecycle
  // ----------------------------------------------------------------
  init() {
    if (this.ctx) return
    if (typeof window === "undefined") return
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext
    if (!Ctx) return
    this.ctx = new Ctx()
    this.master = this.ctx.createGain()
    this.master.gain.value = 0.75
    this.master.connect(this.ctx.destination)
  }

  unlock() {
    this.init()
    if (!this.ctx) return
    if (this.ctx.state === "suspended") {
      void this.ctx.resume()
    }
    this.unlocked = true
  }

  private ready(): boolean {
    if (!this.ctx || !this.master) return false
    if (this.ctx.state === "suspended") void this.ctx.resume()
    return true
  }

  private now(): number {
    return this.ctx!.currentTime
  }

  // ----------------------------------------------------------------
  // PHASE 1: Slider hum (low-frequency drone whose pitch + volume rise
  // with drag progress).
  // ----------------------------------------------------------------
  startSlideHum() {
    if (!this.ready() || this.slideOsc) return
    const ctx = this.ctx!
    const t = this.now()

    const gain = ctx.createGain()
    gain.gain.value = 0
    const lp = ctx.createBiquadFilter()
    lp.type = "lowpass"
    lp.frequency.value = 900
    gain.connect(lp).connect(this.master!)

    // Sub-bass body
    const sub = ctx.createOscillator()
    sub.type = "sine"
    sub.frequency.value = 55
    sub.connect(gain)
    sub.start()

    // Saw shimmer for tactile bite
    const osc = ctx.createOscillator()
    osc.type = "sawtooth"
    osc.frequency.value = 90
    const oscG = ctx.createGain()
    oscG.gain.value = 0.35
    osc.connect(oscG).connect(gain)
    osc.start()

    gain.gain.linearRampToValueAtTime(0.05, t + 0.08)

    this.slideOsc = osc
    this.slideSubOsc = sub
    this.slideGain = gain
  }

  updateSlideHum(progress: number) {
    if (!this.ctx || !this.slideOsc || !this.slideSubOsc || !this.slideGain)
      return
    const t = this.now()
    const p = Math.max(0, Math.min(1, progress))
    const targetSaw = 90 + p * 320 // 90 -> 410 Hz
    const targetSub = 55 + p * 70 // 55 -> 125 Hz
    const targetVol = 0.05 + p * 0.18
    this.slideOsc.frequency.linearRampToValueAtTime(targetSaw, t + 0.06)
    this.slideSubOsc.frequency.linearRampToValueAtTime(targetSub, t + 0.06)
    this.slideGain.gain.linearRampToValueAtTime(targetVol, t + 0.06)
  }

  stopSlideHum() {
    if (!this.ctx || !this.slideOsc || !this.slideGain || !this.slideSubOsc)
      return
    const t = this.now()
    const osc = this.slideOsc
    const sub = this.slideSubOsc
    const g = this.slideGain
    g.gain.cancelScheduledValues(t)
    g.gain.linearRampToValueAtTime(0, t + 0.18)
    window.setTimeout(() => {
      try {
        osc.stop()
        sub.stop()
      } catch {}
    }, 220)
    this.slideOsc = null
    this.slideSubOsc = null
    this.slideGain = null
  }

  // ----------------------------------------------------------------
  // PHASE 2: Shutdown — sharp electric pop + descending power-down drone.
  // ----------------------------------------------------------------
  electricPop() {
    if (!this.ready()) return
    const ctx = this.ctx!
    const t = this.now()

    // Bright noise crack
    const buf = ctx.createBuffer(1, ctx.sampleRate * 0.18, ctx.sampleRate)
    const data = buf.getChannelData(0)
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2.5)
    }
    const src = ctx.createBufferSource()
    src.buffer = buf
    const bp = ctx.createBiquadFilter()
    bp.type = "bandpass"
    bp.frequency.value = 2600
    bp.Q.value = 1.4
    const g = ctx.createGain()
    g.gain.value = 0.55
    src.connect(bp).connect(g).connect(this.master!)
    src.start(t)
    src.stop(t + 0.2)

    // Sharp click body
    const click = ctx.createOscillator()
    const cg = ctx.createGain()
    click.type = "square"
    click.frequency.setValueAtTime(1400, t)
    click.frequency.exponentialRampToValueAtTime(140, t + 0.04)
    cg.gain.setValueAtTime(0.5, t)
    cg.gain.exponentialRampToValueAtTime(0.001, t + 0.05)
    click.connect(cg).connect(this.master!)
    click.start(t)
    click.stop(t + 0.06)
  }

  powerDownDrone() {
    if (!this.ready()) return
    const ctx = this.ctx!
    const t = this.now()

    // Two-osc drone descending into silence
    const make = (startHz: number, endHz: number, vol: number, type: OscillatorType) => {
      const o = ctx.createOscillator()
      const g = ctx.createGain()
      o.type = type
      o.frequency.setValueAtTime(startHz, t)
      o.frequency.exponentialRampToValueAtTime(endHz, t + 1.4)
      g.gain.setValueAtTime(0.0, t)
      g.gain.linearRampToValueAtTime(vol, t + 0.08)
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.5)
      o.connect(g).connect(this.master!)
      o.start(t)
      o.stop(t + 1.6)
    }
    make(220, 22, 0.32, "sine")
    make(330, 28, 0.16, "triangle")
  }

  // ----------------------------------------------------------------
  // PHASE 3: Nebula pad — ethereal looping ambient texture.
  // ----------------------------------------------------------------
  startNebulaPad() {
    if (!this.ready() || this.padMaster) return
    const ctx = this.ctx!

    const padMaster = ctx.createGain()
    padMaster.gain.value = 0
    padMaster.connect(this.master!)

    const filter = ctx.createBiquadFilter()
    filter.type = "lowpass"
    filter.frequency.value = 1200
    filter.Q.value = 0.6
    filter.connect(padMaster)

    // A minor 9 voicing for dreamy, "space" feel
    const freqs = [110, 220, 261.63, 329.63, 415.3]
    for (const f of freqs) {
      const osc = ctx.createOscillator()
      const g = ctx.createGain()
      osc.type = "sine"
      osc.frequency.value = f
      osc.detune.value = (Math.random() - 0.5) * 12
      g.gain.value = 0.06
      osc.connect(g).connect(filter)
      osc.start()
      this.padNodes.push({ osc, gain: g })
    }

    // Slow filter LFO for shimmer
    const lfo = ctx.createOscillator()
    const lfoGain = ctx.createGain()
    lfo.frequency.value = 0.11
    lfoGain.gain.value = 500
    lfo.connect(lfoGain).connect(filter.frequency)
    lfo.start()
    this.padLfo = lfo

    const t = this.now()
    padMaster.gain.linearRampToValueAtTime(0.18, t + 2.5)
    this.padMaster = padMaster
  }

  stopNebulaPad(fadeMs = 1000) {
    if (!this.ctx || !this.padMaster) return
    const t = this.now()
    const padMaster = this.padMaster
    const nodes = this.padNodes
    const lfo = this.padLfo
    padMaster.gain.cancelScheduledValues(t)
    padMaster.gain.linearRampToValueAtTime(0, t + fadeMs / 1000)
    window.setTimeout(() => {
      nodes.forEach((n) => {
        try {
          n.osc.stop()
        } catch {}
      })
      try {
        lfo?.stop()
      } catch {}
      try {
        padMaster.disconnect()
      } catch {}
    }, fadeMs + 80)
    this.padNodes = []
    this.padMaster = null
    this.padLfo = null
  }

  // ----------------------------------------------------------------
  // PHASE 4: Box thumping — rhythmic muffled wood-on-wood, getting
  // faster + louder as the long-press progresses.
  // ----------------------------------------------------------------
  startBoxThump(getProgress: () => number) {
    if (!this.ready() || this.thumpTimer != null) return
    this.thumpGetProgress = getProgress
    const playOne = () => {
      if (!this.ctx || !this.master) return
      const ctx = this.ctx
      const t = this.now()
      const p = Math.max(0, Math.min(1, this.thumpGetProgress?.() ?? 0))

      // Low body kick
      const k = ctx.createOscillator()
      const kg = ctx.createGain()
      k.type = "sine"
      k.frequency.setValueAtTime(140 + p * 60, t)
      k.frequency.exponentialRampToValueAtTime(45, t + 0.14)
      const vol = 0.32 + p * 0.55
      kg.gain.setValueAtTime(0, t)
      kg.gain.linearRampToValueAtTime(vol, t + 0.005)
      kg.gain.exponentialRampToValueAtTime(0.001, t + 0.2)
      k.connect(kg).connect(this.master)
      k.start(t)
      k.stop(t + 0.22)

      // Wooden click on top (low-pass noise burst)
      const buf = ctx.createBuffer(
        1,
        Math.floor(ctx.sampleRate * 0.05),
        ctx.sampleRate,
      )
      const data = buf.getChannelData(0)
      for (let i = 0; i < data.length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 4)
      }
      const noise = ctx.createBufferSource()
      noise.buffer = buf
      const lp = ctx.createBiquadFilter()
      lp.type = "lowpass"
      lp.frequency.value = 700 + p * 800
      const ng = ctx.createGain()
      ng.gain.value = 0.18 + p * 0.3
      noise.connect(lp).connect(ng).connect(this.master)
      noise.start(t)

      // Tempo: 380ms → 95ms
      const interval = 380 - p * 285
      this.thumpTimer = window.setTimeout(playOne, interval)
    }
    this.thumpTimer = window.setTimeout(playOne, 30)
  }

  stopBoxThump() {
    if (this.thumpTimer != null) {
      window.clearTimeout(this.thumpTimer)
      this.thumpTimer = null
    }
    this.thumpGetProgress = null
  }

  // ----------------------------------------------------------------
  // PHASE 5: Magic chime explosion + cheerful orchestral swell.
  // ----------------------------------------------------------------
  magicChimeExplosion() {
    if (!this.ready()) return
    const ctx = this.ctx!
    const t = this.now()

    // Big bright chord stack: C major add9 in the bell range
    const freqs = [523.25, 659.25, 783.99, 987.77, 1174.66, 1568.0]
    freqs.forEach((f, i) => {
      const at = t + i * 0.025
      // fundamental sine bell
      const o = ctx.createOscillator()
      const g = ctx.createGain()
      o.type = "sine"
      o.frequency.value = f
      g.gain.setValueAtTime(0, at)
      g.gain.linearRampToValueAtTime(0.16, at + 0.02)
      g.gain.exponentialRampToValueAtTime(0.001, at + 2.6)
      o.connect(g).connect(this.master!)
      o.start(at)
      o.stop(at + 2.7)

      // octave shimmer (triangle)
      const o2 = ctx.createOscillator()
      const g2 = ctx.createGain()
      o2.type = "triangle"
      o2.frequency.value = f * 2
      g2.gain.setValueAtTime(0, at)
      g2.gain.linearRampToValueAtTime(0.05, at + 0.03)
      g2.gain.exponentialRampToValueAtTime(0.001, at + 1.6)
      o2.connect(g2).connect(this.master!)
      o2.start(at)
      o2.stop(at + 1.7)
    })

    // Burst noise (the explosion crack)
    const buf = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate)
    const data = buf.getChannelData(0)
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 1.4)
    }
    const src = ctx.createBufferSource()
    src.buffer = buf
    const bp = ctx.createBiquadFilter()
    bp.type = "bandpass"
    bp.frequency.value = 1700
    bp.Q.value = 0.9
    const ng = ctx.createGain()
    ng.gain.value = 0.55
    src.connect(bp).connect(ng).connect(this.master!)
    src.start(t)

    // Orchestral swell underneath: low sawtooth opening filter
    const swell = ctx.createOscillator()
    const swell2 = ctx.createOscillator()
    const swellG = ctx.createGain()
    const swellLp = ctx.createBiquadFilter()
    swell.type = "sawtooth"
    swell2.type = "sawtooth"
    swell.frequency.value = 130.81 // C3
    swell2.frequency.value = 196.0 // G3
    swellLp.type = "lowpass"
    swellLp.frequency.setValueAtTime(380, t)
    swellLp.frequency.linearRampToValueAtTime(2400, t + 1.4)
    swellG.gain.setValueAtTime(0, t)
    swellG.gain.linearRampToValueAtTime(0.13, t + 0.6)
    swellG.gain.exponentialRampToValueAtTime(0.001, t + 4.0)
    swell.connect(swellLp)
    swell2.connect(swellLp)
    swellLp.connect(swellG).connect(this.master!)
    swell.start(t)
    swell2.start(t)
    swell.stop(t + 4.1)
    swell2.stop(t + 4.1)
  }

  startFireworks() {
    if (!this.ready() || this.fwTimer != null) return
    const playCrackle = () => {
      if (!this.ctx || !this.master) return
      const ctx = this.ctx
      const t = this.now()

      // Crackling noise burst
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.45, ctx.sampleRate)
      const data = buf.getChannelData(0)
      for (let i = 0; i < data.length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2)
      }
      const src = ctx.createBufferSource()
      src.buffer = buf
      const hp = ctx.createBiquadFilter()
      hp.type = "highpass"
      hp.frequency.value = 1800
      const g = ctx.createGain()
      g.gain.value = 0.12 + Math.random() * 0.16
      src.connect(hp).connect(g).connect(this.master)
      src.start(t)

      // Occasional sparkle bell
      if (Math.random() < 0.55) {
        const o = ctx.createOscillator()
        const og = ctx.createGain()
        o.type = "sine"
        o.frequency.value = 1500 + Math.random() * 1800
        og.gain.setValueAtTime(0, t)
        og.gain.linearRampToValueAtTime(0.06, t + 0.01)
        og.gain.exponentialRampToValueAtTime(0.001, t + 0.55)
        o.connect(og).connect(this.master)
        o.start(t)
        o.stop(t + 0.6)
      }

      // Occasional low boom
      if (Math.random() < 0.25) {
        const o = ctx.createOscillator()
        const og = ctx.createGain()
        o.type = "sine"
        o.frequency.setValueAtTime(110, t)
        o.frequency.exponentialRampToValueAtTime(40, t + 0.35)
        og.gain.setValueAtTime(0, t)
        og.gain.linearRampToValueAtTime(0.18, t + 0.01)
        og.gain.exponentialRampToValueAtTime(0.001, t + 0.4)
        o.connect(og).connect(this.master)
        o.start(t)
        o.stop(t + 0.42)
      }

      const next = 380 + Math.random() * 760
      this.fwTimer = window.setTimeout(playCrackle, next)
    }
    this.fwTimer = window.setTimeout(playCrackle, 350)
  }

  stopFireworks() {
    if (this.fwTimer != null) {
      window.clearTimeout(this.fwTimer)
      this.fwTimer = null
    }
  }

  isUnlocked(): boolean {
    return this.unlocked
  }
}

let _engine: AudioEngine | null = null

export function getAudioEngine(): AudioEngine {
  if (!_engine) _engine = new AudioEngine()
  return _engine
}
