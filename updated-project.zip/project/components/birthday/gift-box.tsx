"use client"

import { useEffect, useRef, useState, type CSSProperties } from "react"
import * as THREE from "three"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js"

const MODEL_URL =
  "https://github.com/fadilelazz/gift-box/raw/refs/heads/main/untitled.glb"

interface Props {
  glow: number        // 0..1  — drives the outer aura intensity
  size?: number
  /** Applied to the lid group during long-press rattle (CSS transform). */
  lidStyle?: CSSProperties
  /** When true the "Animation" clip plays once and clamps at the final frame. */
  triggerOpen?: boolean
}

export default function GiftBox({
  glow,
  size = 180,
  lidStyle,
  triggerOpen = false,
}: Props) {
  const mountRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const mixerRef = useRef<THREE.AnimationMixer | null>(null)
  const actionRef = useRef<THREE.AnimationAction | null>(null)
  const clockRef = useRef(new THREE.Clock())
  const rafRef = useRef<number>(0)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const [loaded, setLoaded] = useState(false)

  /* ── Bootstrap Three.js scene ── */
  useEffect(() => {
    const el = mountRef.current
    if (!el) return

    // Scene
    const scene = new THREE.Scene()
    sceneRef.current = scene

    // Camera
    const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 100)
    camera.position.set(0, 0.15, 2.4)

    // Renderer — transparent background
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setSize(size, size)
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.toneMappingExposure = 1.4
    renderer.setClearColor(0x000000, 0)
    rendererRef.current = renderer
    el.appendChild(renderer.domElement)

    // Lights
    const ambient = new THREE.AmbientLight(0xfff8e7, 1.2)
    scene.add(ambient)

    const key = new THREE.DirectionalLight(0xfff5cc, 3.5)
    key.position.set(2, 4, 3)
    scene.add(key)

    const fill = new THREE.DirectionalLight(0xd4a72c, 1.4)
    fill.position.set(-3, 1, -2)
    scene.add(fill)

    const rim = new THREE.DirectionalLight(0xffffff, 0.8)
    rim.position.set(0, -2, -4)
    scene.add(rim)

    // Load GLB
    const loader = new GLTFLoader()
    loader.load(
      MODEL_URL,
      (gltf) => {
        const model = gltf.scene

        // Centre & auto-scale the model
        const box = new THREE.Box3().setFromObject(model)
        const centre = box.getCenter(new THREE.Vector3())
        const modelSize = box.getSize(new THREE.Vector3())
        const maxDim = Math.max(modelSize.x, modelSize.y, modelSize.z)
        model.position.sub(centre)
        model.scale.setScalar(1.6 / maxDim)
        scene.add(model)

        // Wire up the mixer
        const mixer = new THREE.AnimationMixer(model)
        mixerRef.current = mixer

        // Find clip named "Animation" (fall back to first clip if needed)
        const clip =
          THREE.AnimationClip.findByName(gltf.animations, "Animation") ??
          gltf.animations[0]

        if (clip) {
          const action = mixer.clipAction(clip)
          action.loop = THREE.LoopOnce      // play exactly once
          action.clampWhenFinished = true   // freeze at last frame — never snap back
          actionRef.current = action
        }

        setLoaded(true)

        // Render loop
        const tick = () => {
          rafRef.current = requestAnimationFrame(tick)
          const delta = clockRef.current.getDelta()
          mixer.update(delta)
          renderer.render(scene, camera)
        }
        tick()
      },
      undefined,
      (err) => console.error("GLB load error:", err),
    )

    return () => {
      cancelAnimationFrame(rafRef.current)
      renderer.dispose()
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement)
    }
    // size is stable after mount — ignore dep warning
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* ── Fire the open animation exactly once after long-press completes ── */
  useEffect(() => {
    if (!triggerOpen || !actionRef.current) return
    const action = actionRef.current
    if (!action.isRunning()) {
      action.reset()
      action.play()
    }
  }, [triggerOpen])

  const glowStrength = 0.35 + glow * 0.65

  return (
    <div
      className="relative"
      style={{
        width: size,
        height: size,
        filter: `drop-shadow(0 ${10 + glow * 12}px ${24 + glow * 30}px rgba(255,180,60,${0.25 + glow * 0.5}))`,
      }}
    >
      {/* Outer aura — matches the original CSS gift box */}
      <div
        className="absolute pointer-events-none rounded-full"
        style={{
          inset: -size * 0.35,
          background: `radial-gradient(circle, rgba(255,200,80,${0.18 * glowStrength}) 0%, rgba(255,160,40,${0.08 * glowStrength}) 35%, rgba(0,0,0,0) 70%)`,
        }}
      />

      {/*
        Canvas mount — the lidStyle CSS transform is applied here so the
        entire 3-D render rattles in sync with the long-press interaction.
      */}
      <div
        ref={mountRef}
        className="absolute inset-0"
        style={{
          transformOrigin: "50% 30%",
          willChange: "transform",
          background: "transparent",
          ...lidStyle,
        }}
      />

      {/* Shimmer placeholder while the GLB fetches */}
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center" style={{ opacity: 0.4 }}>
          <div
            className="rounded-lg animate-pulse"
            style={{
              width: "72%",
              height: "72%",
              background: "linear-gradient(135deg, #1a1428 0%, #2a1f3d 50%, #1a1428 100%)",
            }}
          />
        </div>
      )}
    </div>
  )
}
