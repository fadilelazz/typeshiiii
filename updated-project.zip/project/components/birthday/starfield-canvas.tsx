"use client"

import { useEffect, useRef } from "react"

interface Props {
  exploded: boolean
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  color: string
  size: number
  type: "spark" | "confetti" | "dust"
  rotation?: number
  rotSpeed?: number
  w?: number
  h?: number
  gravity: number
  friction: number
}

const GOLD_PALETTE = ["#ffd700", "#ffed8a", "#ffaa3a", "#fff5cc", "#ffcc55", "#ffe27a"]
const HOLO_PALETTE = [
  "#ffd700",
  "#ff7eb3",
  "#7afcff",
  "#feff9c",
  "#fff5cc",
  "#ffba6b",
  "#c2a3ff",
]

export default function StarfieldCanvas({ exploded }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const explodedRef = useRef(exploded)

  useEffect(() => {
    explodedRef.current = exploded
  }, [exploded])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d", { alpha: false })
    if (!ctx) return

    let w = 0
    let h = 0
    let dpr = 1

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth
      h = canvas.clientHeight
      canvas.width = Math.floor(w * dpr)
      canvas.height = Math.floor(h * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener("resize", resize)

    // Stars with depth (parallax)
    const stars = Array.from({ length: 240 }, () => {
      const depth = Math.random()
      return {
        x: Math.random() * w,
        y: Math.random() * h,
        r: 0.3 + Math.random() * 1.4 + depth * 0.6,
        tw: Math.random() * Math.PI * 2,
        twSpeed: 0.5 + Math.random() * 1.8,
        depth,
        baseAlpha: 0.4 + depth * 0.55,
      }
    })

    // Pre-rendered nebula (drawn each frame but inexpensive due to opacity)
    const nebulas = [
      { x: w * 0.3, y: h * 0.35, r: Math.max(w, h) * 0.7, color: "rgba(120, 60, 200, 0.10)" },
      { x: w * 0.78, y: h * 0.78, r: Math.max(w, h) * 0.55, color: "rgba(220, 170, 60, 0.07)" },
      { x: w * 0.15, y: h * 0.85, r: Math.max(w, h) * 0.5, color: "rgba(80, 30, 140, 0.08)" },
    ]

    // Drifting gold dust around the gift (visible always, intensifies on explosion)
    const dust: Particle[] = Array.from({ length: 28 }, () => ({
      x: w / 2 + (Math.random() - 0.5) * 220,
      y: h / 2 + (Math.random() - 0.5) * 220,
      vx: (Math.random() - 0.5) * 0.25,
      vy: -0.1 - Math.random() * 0.25,
      life: 0,
      maxLife: 9999,
      color: GOLD_PALETTE[Math.floor(Math.random() * GOLD_PALETTE.length)],
      size: 0.7 + Math.random() * 1.4,
      type: "dust",
      gravity: 0,
      friction: 1,
    }))

    const particles: Particle[] = []

    const spawnFirework = (cx?: number, cy?: number, big = false) => {
      const x = cx ?? w * (0.15 + Math.random() * 0.7)
      const y = cy ?? h * (0.1 + Math.random() * 0.45)
      const count = big ? 90 : 50
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2 + Math.random() * 0.15
        const speed = (big ? 2.2 : 1.4) + Math.random() * (big ? 5 : 3.5)
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 0,
          maxLife: 70 + Math.random() * 50,
          color: (big ? HOLO_PALETTE : GOLD_PALETTE)[
            Math.floor(Math.random() * (big ? HOLO_PALETTE.length : GOLD_PALETTE.length))
          ],
          size: 1.4 + Math.random() * 2.2,
          type: "spark",
          gravity: 0.045,
          friction: 0.985,
        })
      }
    }

    const spawnConfetti = (count = 40, fromTop = true) => {
      for (let i = 0; i < count; i++) {
        particles.push({
          x: fromTop ? Math.random() * w : w / 2 + (Math.random() - 0.5) * 80,
          y: fromTop ? -10 - Math.random() * 60 : h / 2,
          vx: (Math.random() - 0.5) * (fromTop ? 1.2 : 5),
          vy: fromTop ? 1 + Math.random() * 2 : -3 - Math.random() * 4,
          life: 0,
          maxLife: 600,
          color: HOLO_PALETTE[Math.floor(Math.random() * HOLO_PALETTE.length)],
          size: 0,
          type: "confetti",
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: (Math.random() - 0.5) * 0.25,
          w: 4 + Math.random() * 5,
          h: 8 + Math.random() * 8,
          gravity: 0.025,
          friction: 1,
        })
      }
    }

    let didExplode = false
    let nextFireworkAt = 0
    let frame = 0
    let raf = 0

    const draw = () => {
      frame += 1

      // Background gradient (deep space)
      const bg = ctx.createRadialGradient(
        w / 2,
        h * 0.4,
        0,
        w / 2,
        h * 0.4,
        Math.max(w, h),
      )
      bg.addColorStop(0, "#0a0820")
      bg.addColorStop(0.45, "#050316")
      bg.addColorStop(1, "#000000")
      ctx.fillStyle = bg
      ctx.fillRect(0, 0, w, h)

      // Nebulas
      for (const n of nebulas) {
        const g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r)
        g.addColorStop(0, n.color)
        g.addColorStop(1, "rgba(0,0,0,0)")
        ctx.fillStyle = g
        ctx.fillRect(0, 0, w, h)
      }

      // Stars
      for (const s of stars) {
        s.tw += 0.025 * s.twSpeed
        const tw = (Math.sin(s.tw) + 1) * 0.5 // 0..1
        const alpha = s.baseAlpha * (0.55 + tw * 0.45)
        ctx.beginPath()
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 240, 220, ${alpha})`
        ctx.fill()
        // Cross-flare on bright stars
        if (s.r > 1.4 && tw > 0.85) {
          ctx.strokeStyle = `rgba(255, 240, 200, ${alpha * 0.5})`
          ctx.lineWidth = 0.6
          ctx.beginPath()
          ctx.moveTo(s.x - s.r * 3, s.y)
          ctx.lineTo(s.x + s.r * 3, s.y)
          ctx.moveTo(s.x, s.y - s.r * 3)
          ctx.lineTo(s.x, s.y + s.r * 3)
          ctx.stroke()
        }
      }

      // Gold dust (gentle ambient particles)
      for (const p of dust) {
        p.x += p.vx
        p.y += p.vy
        // wrap softly around screen center
        if (p.y < h / 2 - 200) {
          p.y = h / 2 + 200
          p.x = w / 2 + (Math.random() - 0.5) * 240
        }
        if (p.x < 0) p.x = w
        if (p.x > w) p.x = 0
        const flicker = 0.55 + Math.sin((frame + p.x) * 0.05) * 0.45
        ctx.save()
        ctx.shadowColor = p.color
        ctx.shadowBlur = 8
        ctx.globalAlpha = 0.6 * flicker
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      }

      // Trigger explosion once
      if (explodedRef.current && !didExplode) {
        didExplode = true
        // multiple staggered bursts at center
        spawnFirework(w / 2, h / 2, true)
        for (let i = 1; i <= 4; i++) {
          window.setTimeout(() => {
            spawnFirework(
              w / 2 + (Math.random() - 0.5) * 160,
              h / 2 + (Math.random() - 0.5) * 160,
              true,
            )
            spawnConfetti(40, false)
          }, i * 130)
        }
        spawnConfetti(120, true)
        nextFireworkAt = frame + 25
      }

      // Continuous fireworks after explosion
      if (didExplode && frame > nextFireworkAt) {
        spawnFirework()
        nextFireworkAt = frame + 30 + Math.floor(Math.random() * 60)
        if (Math.random() < 0.5) spawnConfetti(20, true)
      }

      // Update + draw particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i]
        p.life += 1
        p.x += p.vx
        p.y += p.vy
        p.vy += p.gravity
        p.vx *= p.friction

        if (
          p.life > p.maxLife ||
          p.y > h + 40 ||
          p.x < -40 ||
          p.x > w + 40
        ) {
          particles.splice(i, 1)
          continue
        }

        if (p.type === "spark") {
          const lifeRatio = p.life / p.maxLife
          const alpha = Math.max(0, 1 - lifeRatio) * (lifeRatio < 0.1 ? lifeRatio * 10 : 1)
          ctx.save()
          ctx.globalAlpha = alpha
          ctx.shadowColor = p.color
          ctx.shadowBlur = 14
          ctx.fillStyle = p.color
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.fill()
          // trailing tail
          ctx.globalAlpha = alpha * 0.4
          ctx.beginPath()
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(p.x - p.vx * 3, p.y - p.vy * 3)
          ctx.strokeStyle = p.color
          ctx.lineWidth = p.size * 0.8
          ctx.lineCap = "round"
          ctx.stroke()
          ctx.restore()
        } else if (p.type === "confetti") {
          const alpha = Math.min(1, (1 - p.life / p.maxLife) * 1.6)
          ctx.save()
          ctx.globalAlpha = alpha
          ctx.translate(p.x, p.y)
          ctx.rotate(p.rotation || 0)
          if (p.rotation !== undefined && p.rotSpeed !== undefined) {
            p.rotation += p.rotSpeed
          }
          // holographic shimmer band
          const grad = ctx.createLinearGradient(
            -(p.w || 4) / 2,
            0,
            (p.w || 4) / 2,
            0,
          )
          grad.addColorStop(0, p.color)
          grad.addColorStop(0.5, "#ffffff")
          grad.addColorStop(1, p.color)
          ctx.fillStyle = grad
          ctx.fillRect(-(p.w || 4) / 2, -(p.h || 8) / 2, p.w || 4, p.h || 8)
          ctx.restore()
        }
      }

      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener("resize", resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 h-full w-full"
      aria-hidden
    />
  )
}
