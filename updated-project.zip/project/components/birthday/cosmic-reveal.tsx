"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import GiftBox from "./gift-box"
import StarfieldCanvas from "./starfield-canvas"
import { getAudioEngine } from "@/lib/audio-engine"

const HOLD_DURATION = 2500

export default function CosmicReveal() {
  const [holding, setHolding] = useState(false)
  const [progress, setProgress] = useState(0)
  const [exploded, setExploded] = useState(false)
  const holdStartRef = useRef<number | null>(null)
  const rafRef = useRef<number | null>(null)
  const explodedRef = useRef(false)
  const progressRef = useRef(0)
  const [revealOpacity, setRevealOpacity] = useState(0)

  // Per-frame lid jitter
  const [lidJitter, setLidJitter] = useState({ x: 0, y: 0, r: 0 })
  const lidRafRef = useRef<number | null>(null)

  // Keep a live ref of progress so audio's getProgress() reflects the latest
  useEffect(() => {
    progressRef.current = progress
  }, [progress])

  // ---- Audio: nebula pad on mount, fade out / cleanup on unmount ----
  useEffect(() => {
    const audio = getAudioEngine()
    // Slight delay so it blooms in alongside the visual fade
    const timer = window.setTimeout(() => audio.startNebulaPad(), 250)
    return () => {
      window.clearTimeout(timer)
      audio.stopBoxThump()
      audio.stopNebulaPad(600)
      audio.stopFireworks()
    }
  }, [])

  // ---- Visual fade-in for the whole phase ----
  useEffect(() => {
    let raf = 0
    const start = performance.now()
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / 1400)
      setRevealOpacity(k)
      if (k < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  // ---- Long press progress + thump audio ----
  useEffect(() => {
    const audio = getAudioEngine()

    if (!holding || explodedRef.current) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      audio.stopBoxThump()
      // Smoothly reset progress if released early
      if (!explodedRef.current && progress > 0) {
        const start = performance.now()
        const startVal = progress
        const decay = (t: number) => {
          const k = Math.min(1, (t - start) / 280)
          const next = startVal * (1 - k)
          setProgress(next)
          if (k < 1) rafRef.current = requestAnimationFrame(decay)
        }
        rafRef.current = requestAnimationFrame(decay)
      }
      holdStartRef.current = null
      return
    }

    // Start thumps that read live progress
    audio.startBoxThump(() => progressRef.current)

    holdStartRef.current = performance.now() - progress * HOLD_DURATION
    const tick = (t: number) => {
      const start = holdStartRef.current
      if (start == null) return
      const elapsed = t - start
      const p = Math.min(1, elapsed / HOLD_DURATION)
      setProgress(p)
      if (p >= 1) {
        explodedRef.current = true
        setExploded(true)
        setHolding(false)
        // Trigger climactic audio sequence
        audio.stopBoxThump()
        audio.stopNebulaPad(900)
        audio.magicChimeExplosion()
        // Crackling fireworks crossfade in
        window.setTimeout(() => audio.startFireworks(), 350)
        return
      }
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [holding])

  // ---- Per-frame violent lid rattle, scales with progress ----
  useEffect(() => {
    if (!holding || progress < 0.04) {
      if (lidRafRef.current) cancelAnimationFrame(lidRafRef.current)
      // Smoothly settle the lid back
      let raf = 0
      const start = performance.now()
      const startJ = lidJitter
      const settle = (t: number) => {
        const k = Math.min(1, (t - start) / 200)
        setLidJitter({
          x: startJ.x * (1 - k),
          y: startJ.y * (1 - k),
          r: startJ.r * (1 - k),
        })
        if (k < 1) raf = requestAnimationFrame(settle)
      }
      raf = requestAnimationFrame(settle)
      return () => cancelAnimationFrame(raf)
    }

    const tick = () => {
      const p = progressRef.current
      // Amplitude grows non-linearly: gentle at first, violent near end
      const amp = Math.pow(p, 1.3)
      const xRange = 7 * amp
      const yRange = 5 * amp
      const rRange = 6 * amp
      setLidJitter({
        x: (Math.random() * 2 - 1) * xRange,
        y: (Math.random() * 2 - 1) * yRange - amp * 1.5, // slight upward bias
        r: (Math.random() * 2 - 1) * rRange,
      })
      lidRafRef.current = requestAnimationFrame(tick)
    }
    lidRafRef.current = requestAnimationFrame(tick)
    return () => {
      if (lidRafRef.current) cancelAnimationFrame(lidRafRef.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [holding, progress > 0.04])

  const startHold = useCallback(() => {
    if (explodedRef.current) return
    // Defensive: ensure context resumes (in case of suspension on iOS)
    getAudioEngine().unlock()
    setHolding(true)
  }, [])

  const endHold = useCallback(() => {
    setHolding(false)
  }, [])

  const lidStyle: React.CSSProperties = {
    transform: `translate3d(${lidJitter.x.toFixed(2)}px, ${lidJitter.y.toFixed(2)}px, 0) rotate(${lidJitter.r.toFixed(2)}deg)`,
  }

  return (
    <div
      className="absolute inset-0"
      style={{ opacity: revealOpacity, transition: "opacity 200ms linear" }}
    >
      <StarfieldCanvas exploded={exploded} />

      {/* Vignette for depth */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, rgba(0,0,0,0) 40%, rgba(0,0,0,0.6) 100%)",
        }}
      />

      {/* Gift + Press and Hold UI — gift stays visible after explosion to show open animation */}
      <div
        className="absolute inset-0 flex flex-col items-center justify-center gap-10 px-6"
        style={{ pointerEvents: exploded ? "none" : "auto" }}
      >
        <div
          role="button"
          tabIndex={0}
          aria-label="Press and hold the gift"
          className="relative cursor-pointer outline-none"
          style={{
            touchAction: "none",
            WebkitTapHighlightColor: "transparent",
            pointerEvents: exploded ? "none" : "auto",
          }}
          onMouseDown={(e) => {
            e.preventDefault()
            startHold()
          }}
          onMouseUp={endHold}
          onMouseLeave={endHold}
          onTouchStart={(e) => {
            e.preventDefault()
            startHold()
          }}
          onTouchEnd={(e) => {
            e.preventDefault()
            endHold()
          }}
          onTouchCancel={endHold}
        >
          {/* Hover float wrapper (paused while holding or after exploded) */}
          <div
            className={holding || exploded ? "" : "float-y"}
            style={{
              transformOrigin: "center center",
              transform: holding ? `scale(${1 + progress * 0.04})` : undefined,
              transition: holding ? undefined : "transform 220ms ease-out",
            }}
          >
            <GiftBox
              glow={exploded ? 1 : progress}
              lidStyle={exploded ? undefined : lidStyle}
              triggerOpen={exploded}
            />
          </div>

          {/* Progress ring — hidden after explosion */}
          {!exploded && (
            <ProgressRing progress={progress} visible={progress > 0.001} />
          )}
        </div>

        {/* Press and Hold text — fades out as progress grows, gone after explosion */}
        {!exploded && (
          <p
            className="pulse-soft font-sans text-[15px] uppercase tracking-[0.2em] text-white/85"
            style={{
              opacity: 1 - progress * 0.6,
              transition: "opacity 120ms linear",
            }}
          >
            Press &amp; Hold
          </p>
        )}
      </div>

      {/* Celebration text */}
      {exploded && <CelebrationText />}
    </div>
  )
}

function ProgressRing({
  progress,
  visible,
}: {
  progress: number
  visible: boolean
}) {
  const size = 240
  const stroke = 4
  const radius = size / 2 - stroke / 2
  const circumference = 2 * Math.PI * radius
  const dashOffset = circumference * (1 - progress)
  // Gentle pulse on the ring itself
  const pulse = 1 + Math.sin(progress * Math.PI * 4) * 0.015 * progress

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className="absolute pointer-events-none"
      style={{
        left: "50%",
        top: "50%",
        transform: `translate(-50%, -50%) scale(${pulse})`,
        opacity: visible ? 1 : 0,
        transition: "opacity 150ms linear",
        filter: `drop-shadow(0 0 ${6 + progress * 14}px rgba(255,200,60,${0.4 + progress * 0.6}))`,
      }}
      aria-hidden
    >
      <defs>
        <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fff5cc" />
          <stop offset="50%" stopColor="#ffd700" />
          <stop offset="100%" stopColor="#b8860b" />
        </linearGradient>
      </defs>
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="rgba(255,215,0,0.08)"
        strokeWidth={stroke}
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="url(#ringGrad)"
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={dashOffset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dashoffset 60ms linear" }}
      />
    </svg>
  )
}

function CelebrationText() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-8 pointer-events-none">
      <h1
        className="fade-in-up title-glow gold-text font-serif text-center font-bold leading-[1.05] text-balance"
        style={{
          fontSize: "clamp(2.6rem, 12vw, 5rem)",
          letterSpacing: "-0.01em",
        }}
      >
        Happy Birthday!
      </h1>
      <p
        className="silver-text mt-6 font-serif italic text-center text-pretty"
        style={{
          fontSize: "clamp(0.95rem, 3.4vw, 1.25rem)",
          maxWidth: "30ch",
          animation: "fade-in-up 1.6s ease-out 0.6s both",
          textShadow: "0 0 14px rgba(255,255,255,0.25)",
        }}
      >
        Wishing you a universe of joy and a year of endless possibilities.
      </p>
    </div>
  )
}
