"use client"

import { Maximize2 } from "lucide-react"
import { requestFullscreen, useFullscreenState } from "@/lib/fullscreen"

interface Props {
  /** Hide the button entirely (e.g. during the cinematic blackout). */
  hidden?: boolean
}

export default function FullscreenButton({ hidden = false }: Props) {
  const { isFullscreen, supported } = useFullscreenState()
  const visible = supported && !isFullscreen && !hidden

  return (
    <button
      type="button"
      aria-label="Enter fullscreen"
      onClick={() => requestFullscreen()}
      className="fixed z-50 flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-2 font-sans text-[11px] tracking-wide text-white/70 backdrop-blur-md transition hover:bg-white/10 hover:text-white active:scale-95"
      style={{
        right: "max(env(safe-area-inset-right), 14px)",
        bottom: "max(env(safe-area-inset-bottom), 14px)",
        opacity: visible ? 1 : 0,
        pointerEvents: visible ? "auto" : "none",
        transition: "opacity 500ms ease-out, transform 200ms ease-out",
      }}
    >
      <Maximize2 size={13} strokeWidth={2} />
      <span>Full screen</span>
    </button>
  )
}
