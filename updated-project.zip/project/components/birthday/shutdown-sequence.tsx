"use client"

import { Loader2 } from "lucide-react"
import { useEffect, useState } from "react"
import { getAudioEngine } from "@/lib/audio-engine"

interface Props {
  onComplete: () => void
}

type Stage = "turning-off" | "crt" | "blackout"

const TURNING_OFF_MS = 1500
const CRT_MS = 1000
const BLACKOUT_MS = 2000

export default function ShutdownSequence({ onComplete }: Props) {
  const [stage, setStage] = useState<Stage>("turning-off")

  useEffect(() => {
    const audio = getAudioEngine()
    const t1 = window.setTimeout(() => {
      setStage("crt")
      // The instant the screen "collapses": sharp pop + descending drone
      audio.electricPop()
      audio.powerDownDrone()
    }, TURNING_OFF_MS)
    const t2 = window.setTimeout(
      () => setStage("blackout"),
      TURNING_OFF_MS + CRT_MS,
    )
    const t3 = window.setTimeout(
      () => onComplete(),
      TURNING_OFF_MS + CRT_MS + BLACKOUT_MS,
    )
    return () => {
      window.clearTimeout(t1)
      window.clearTimeout(t2)
      window.clearTimeout(t3)
    }
  }, [onComplete])

  return (
    <div className="absolute inset-0 bg-black overflow-hidden">
      {stage === "turning-off" && (
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <div className="flex items-center gap-3 text-white/75 font-mono text-sm tracking-wide">
            <Loader2 className="size-4 animate-spin" strokeWidth={1.5} />
            <span>Turning off...</span>
          </div>
        </div>
      )}

      {stage === "crt" && (
        <div
          className="absolute inset-0 crt-collapse"
          style={{
            transformOrigin: "center center",
            background:
              "radial-gradient(ellipse at center, #ffffff 0%, #f4f4f4 60%, #d8d8d8 100%)",
          }}
        />
      )}
    </div>
  )
}
