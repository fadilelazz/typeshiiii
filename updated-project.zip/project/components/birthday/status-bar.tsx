"use client"

import { useEffect, useState } from "react"

interface Props {
  /** 0..1 — 1 = fully visible, 0 = hidden. */
  opacity: number
}

type BatteryLike = {
  level: number
  charging: boolean
  addEventListener: (event: string, fn: () => void) => void
  removeEventListener: (event: string, fn: () => void) => void
}

export default function StatusBar({ opacity }: Props) {
  const [time, setTime] = useState<string>("")
  const [battery, setBattery] = useState<{ level: number; charging: boolean }>({
    level: 0.86,
    charging: false,
  })

  // Live clock — updates each minute
  useEffect(() => {
    const fmt = () => {
      const d = new Date()
      const h = d.getHours()
      const m = d.getMinutes()
      const hh = ((h + 11) % 12) + 1
      const mm = m.toString().padStart(2, "0")
      setTime(`${hh}:${mm}`)
    }
    fmt()
    const id = window.setInterval(fmt, 15_000)
    return () => window.clearInterval(id)
  }, [])

  // Real battery via the Battery Status API where available
  useEffect(() => {
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryLike>
    }
    if (!nav.getBattery) return
    let bat: BatteryLike | null = null
    let cancelled = false
    const sync = () => {
      if (!bat) return
      setBattery({ level: bat.level, charging: bat.charging })
    }
    nav.getBattery().then((b) => {
      if (cancelled) return
      bat = b
      sync()
      bat.addEventListener("levelchange", sync)
      bat.addEventListener("chargingchange", sync)
    })
    return () => {
      cancelled = true
      if (bat) {
        bat.removeEventListener("levelchange", sync)
        bat.removeEventListener("chargingchange", sync)
      }
    }
  }, [])

  const batteryPct = Math.max(4, Math.round(battery.level * 100))
  const batteryFillColor =
    batteryPct <= 20 ? "#ff453a" : battery.charging ? "#30d158" : "#ffffff"

  return (
    <div
      aria-hidden
      className="pointer-events-none absolute left-0 right-0 top-0 z-40 flex items-center justify-between px-6 pt-3 font-sans text-[13px] text-white"
      style={{
        opacity,
        transition: "opacity 700ms ease-out",
        // Sit just below any safe-area inset
        paddingTop: "max(env(safe-area-inset-top), 12px)",
      }}
    >
      {/* Left — time */}
      <span
        className="font-semibold tracking-tight tabular-nums"
        style={{ fontFeatureSettings: '"tnum"' }}
      >
        {time || "9:41"}
      </span>

      {/* Right — signal, wifi, battery */}
      <div className="flex items-center gap-1.5">
        {/* Cellular signal: 4 ascending bars */}
        <svg
          width="18"
          height="12"
          viewBox="0 0 18 12"
          fill="currentColor"
          className="opacity-95"
        >
          <rect x="0" y="8" width="3" height="4" rx="0.6" />
          <rect x="5" y="5" width="3" height="7" rx="0.6" />
          <rect x="10" y="2" width="3" height="10" rx="0.6" />
          <rect
            x="15"
            y="0"
            width="3"
            height="12"
            rx="0.6"
            opacity="0.45"
          />
        </svg>

        {/* Wi‑Fi arcs */}
        <svg
          width="16"
          height="12"
          viewBox="0 0 16 12"
          fill="none"
          stroke="currentColor"
          className="opacity-95"
        >
          <path
            d="M1 4.5C3 2.5 5.4 1.4 8 1.4C10.6 1.4 13 2.5 15 4.5"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M3.4 6.8C4.7 5.6 6.3 5 8 5C9.7 5 11.3 5.6 12.6 6.8"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M5.7 9C6.3 8.5 7.1 8.2 8 8.2C8.9 8.2 9.7 8.5 10.3 9"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <circle cx="8" cy="11" r="0.9" fill="currentColor" />
        </svg>

        {/* Battery */}
        <div className="ml-1 flex items-center">
          <div
            className="relative rounded-[3px]"
            style={{
              width: 22,
              height: 11,
              border: "1px solid rgba(255,255,255,0.7)",
              padding: 1,
            }}
          >
            <div
              style={{
                width: `${batteryPct}%`,
                height: "100%",
                borderRadius: 1.5,
                background: batteryFillColor,
                transition: "width 400ms ease-out, background 300ms ease-out",
              }}
            />
            {battery.charging && (
              <svg
                viewBox="0 0 8 12"
                className="absolute inset-0 m-auto"
                width="6"
                height="9"
                fill="#000"
              >
                <path d="M5 0L0 7H3L2 12L8 5H5L6 0H5Z" />
              </svg>
            )}
          </div>
          {/* Battery cap */}
          <div
            className="ml-[1px] rounded-r-[1px]"
            style={{
              width: 2,
              height: 5,
              background: "rgba(255,255,255,0.7)",
            }}
          />
        </div>
      </div>
    </div>
  )
}
