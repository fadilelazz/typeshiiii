import BirthdayExperience from "@/components/birthday/birthday-experience"

export default function Page() {
  return <BirthdayExperience />
}
