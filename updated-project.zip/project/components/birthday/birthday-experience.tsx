"use client"

import { useState } from "react"
import PowerOffSlider from "./power-off-slider"
import ShutdownSequence from "./shutdown-sequence"
import CosmicReveal from "./cosmic-reveal"
import StatusBar from "./status-bar"
import FullscreenButton from "./fullscreen-button"

export type Phase = "slider" | "shutdown" | "cosmos"

export default function BirthdayExperience() {
  const [phase, setPhase] = useState<Phase>("slider")

  // Status bar is fully visible during the slider phase, then fades out as
  // the device "powers off" and stays hidden through the cosmic reveal.
  const statusBarOpacity = phase === "slider" ? 0.92 : 0

  return (
    <main
      className="fixed inset-0 h-[100dvh] w-screen overflow-hidden bg-black select-none"
      style={{ touchAction: "none" }}
    >
      {phase === "slider" && (
        <PowerOffSlider onComplete={() => setPhase("shutdown")} />
      )}
      {phase === "shutdown" && (
        <ShutdownSequence onComplete={() => setPhase("cosmos")} />
      )}
      {phase === "cosmos" && <CosmicReveal />}

      {/* Fake phone status bar — sits above all phases, fades during shutdown */}
      <StatusBar opacity={statusBarOpacity} />

      {/* Subtle re-enter-fullscreen affordance, hidden during the blackout */}
      <FullscreenButton hidden={phase === "shutdown"} />
    </main>
  )
}
