// Cross-browser fullscreen helpers + a tiny React hook that tracks state.
"use client"

import { useEffect, useState } from "react"

type FSDocument = Document & {
  webkitFullscreenElement?: Element | null
  webkitExitFullscreen?: () => Promise<void>
  msFullscreenElement?: Element | null
  msExitFullscreen?: () => Promise<void>
}

type FSElement = HTMLElement & {
  webkitRequestFullscreen?: () => Promise<void>
  msRequestFullscreen?: () => Promise<void>
}

export function isFullscreen(): boolean {
  if (typeof document === "undefined") return false
  const d = document as FSDocument
  return Boolean(
    d.fullscreenElement || d.webkitFullscreenElement || d.msFullscreenElement,
  )
}

export async function requestFullscreen(el?: HTMLElement): Promise<void> {
  if (typeof document === "undefined") return
  const target = (el ?? document.documentElement) as FSElement
  try {
    if (target.requestFullscreen) {
      await target.requestFullscreen({ navigationUI: "hide" }).catch(() => {})
    } else if (target.webkitRequestFullscreen) {
      await target.webkitRequestFullscreen()
    } else if (target.msRequestFullscreen) {
      await target.msRequestFullscreen()
    }
  } catch {
    // iOS Safari doesn't allow document fullscreen; we silently fail and
    // the experience still runs full-bleed via 100dvh.
  }
}

export async function exitFullscreen(): Promise<void> {
  if (typeof document === "undefined") return
  const d = document as FSDocument
  try {
    if (d.exitFullscreen) await d.exitFullscreen()
    else if (d.webkitExitFullscreen) await d.webkitExitFullscreen()
    else if (d.msExitFullscreen) await d.msExitFullscreen()
  } catch {
    // ignore
  }
}

/**
 * Returns whether the document is currently in fullscreen, plus a boolean
 * that indicates whether the API is supported at all (so we can hide the
 * "Enter fullscreen" affordance on iOS Safari, where it isn't).
 */
export function useFullscreenState() {
  const [fs, setFs] = useState(false)
  const [supported, setSupported] = useState(false)

  useEffect(() => {
    const d = document as FSDocument
    const el = document.documentElement as FSElement
    setSupported(
      Boolean(
        el.requestFullscreen ||
          el.webkitRequestFullscreen ||
          el.msRequestFullscreen,
      ),
    )

    const sync = () => setFs(isFullscreen())
    sync()
    document.addEventListener("fullscreenchange", sync)
    document.addEventListener("webkitfullscreenchange", sync)
    document.addEventListener("msfullscreenchange", sync)
    return () => {
      document.removeEventListener("fullscreenchange", sync)
      document.removeEventListener("webkitfullscreenchange", sync)
      document.removeEventListener("msfullscreenchange", sync)
    }
  }, [])

  return { isFullscreen: fs, supported }
}
