"use client"

import { Power } from "lucide-react"
import { useCallback, useEffect, useRef, useState } from "react"
import { getAudioEngine } from "@/lib/audio-engine"
import { requestFullscreen } from "@/lib/fullscreen"

interface Props {
  onComplete: () => void
}

const TRACK_WIDTH = 300
const KNOB_SIZE = 56
const PADDING = 4
const MAX_OFFSET = TRACK_WIDTH - KNOB_SIZE - PADDING * 2

export default function PowerOffSlider({ onComplete }: Props) {
  const [offset, setOffset] = useState(0)
  const [dragging, setDragging] = useState(false)
  const [completing, setCompleting] = useState(false)
  const startXRef = useRef(0)
  const startOffsetRef = useRef(0)

  const progress = Math.min(1, offset / MAX_OFFSET)

  const onPointerDown = (clientX: number) => {
    if (completing) return
    // First user gesture: request fullscreen, unlock audio, start the slide hum
    void requestFullscreen()
    const audio = getAudioEngine()
    audio.unlock()
    audio.startSlideHum()
    setDragging(true)
    startXRef.current = clientX
    startOffsetRef.current = offset
  }

  const onPointerMove = useCallback(
    (clientX: number) => {
      if (!dragging || completing) return
      const dx = clientX - startXRef.current
      const next = Math.max(
        0,
        Math.min(MAX_OFFSET, startOffsetRef.current + dx),
      )
      setOffset(next)
      // Pitch + volume of hum follow drag progress
      getAudioEngine().updateSlideHum(next / MAX_OFFSET)
      if (next >= MAX_OFFSET - 0.5) {
        setCompleting(true)
        setDragging(false)
        // Final spike then cut the hum as we transition
        getAudioEngine().updateSlideHum(1)
        window.setTimeout(() => {
          getAudioEngine().stopSlideHum()
          onComplete()
        }, 220)
      }
    },
    [dragging, completing, onComplete],
  )

  const onPointerUp = useCallback(() => {
    if (!dragging) return
    setDragging(false)
    // Cut the hum if user lets go before completing
    if (!completing) getAudioEngine().stopSlideHum()
    if (offset < MAX_OFFSET) {
      // animate back to 0
      const start = offset
      const startTime = performance.now()
      const duration = 280
      const tick = (t: number) => {
        const elapsed = t - startTime
        const k = Math.min(1, elapsed / duration)
        const eased = 1 - Math.pow(1 - k, 3)
        setOffset(start * (1 - eased))
        if (k < 1) requestAnimationFrame(tick)
      }
      requestAnimationFrame(tick)
    }
  }, [dragging, offset, completing])

  // Global listeners while dragging
  useEffect(() => {
    if (!dragging) return
    const move = (e: MouseEvent) => onPointerMove(e.clientX)
    const upMouse = () => onPointerUp()
    const tMove = (e: TouchEvent) => {
      if (e.touches[0]) onPointerMove(e.touches[0].clientX)
    }
    const tUp = () => onPointerUp()
    window.addEventListener("mousemove", move)
    window.addEventListener("mouseup", upMouse)
    window.addEventListener("touchmove", tMove, { passive: false })
    window.addEventListener("touchend", tUp)
    window.addEventListener("touchcancel", tUp)
    return () => {
      window.removeEventListener("mousemove", move)
      window.removeEventListener("mouseup", upMouse)
      window.removeEventListener("touchmove", tMove)
      window.removeEventListener("touchend", tUp)
      window.removeEventListener("touchcancel", tUp)
    }
  }, [dragging, onPointerMove, onPointerUp])

  // Background fades from black to charcoal as user drags
  const bgLightness = 0 + progress * 12 // 0 -> 12
  const textOpacity = 1 - progress * 1.1

  return (
    <div
      className="absolute inset-0 flex flex-col items-center justify-center transition-colors"
      style={{
        backgroundColor: `rgb(${bgLightness}, ${bgLightness}, ${bgLightness + 1})`,
      }}
    >
      {/* Slider */}
      <div
        className="relative"
        style={{
          width: TRACK_WIDTH,
          height: KNOB_SIZE + PADDING * 2,
          opacity: completing ? 0 : 1,
          transition: completing ? "opacity 200ms ease-out" : undefined,
        }}
      >
        {/* Track */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "linear-gradient(180deg, rgba(28,28,32,0.95) 0%, rgba(14,14,16,0.95) 100%)",
            boxShadow:
              "inset 0 1px 0 rgba(255,255,255,0.05), inset 0 -1px 0 rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)",
            backdropFilter: "blur(10px)",
          }}
        />

        {/* Filled track behind knob */}
        <div
          className="absolute top-0 left-0 h-full rounded-full pointer-events-none"
          style={{
            width: offset + KNOB_SIZE + PADDING * 2,
            background:
              "linear-gradient(90deg, rgba(220,40,40,0.0) 0%, rgba(220,40,40,0.18) 100%)",
            transition: dragging ? undefined : "width 280ms cubic-bezier(.2,.8,.2,1)",
          }}
        />

        {/* Label */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{ opacity: textOpacity }}
        >
          <span
            className="shimmer-text font-sans text-[15px] font-medium tracking-wide"
            style={{ paddingLeft: KNOB_SIZE * 0.6 }}
          >
            slide to power off
          </span>
        </div>

        {/* Knob */}
        <button
          type="button"
          aria-label="Slide to power off"
          onMouseDown={(e) => {
            e.preventDefault()
            onPointerDown(e.clientX)
          }}
          onTouchStart={(e) => {
            if (e.touches[0]) onPointerDown(e.touches[0].clientX)
          }}
          className="absolute top-1/2 -translate-y-1/2 rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing"
          style={{
            left: PADDING + offset,
            width: KNOB_SIZE,
            height: KNOB_SIZE,
            background:
              "radial-gradient(circle at 35% 30%, #ff6b6b 0%, #e63946 45%, #b8202d 100%)",
            boxShadow:
              "0 6px 16px rgba(220,40,40,0.45), 0 0 0 1px rgba(255,255,255,0.08), inset 0 1px 0 rgba(255,255,255,0.35), inset 0 -2px 4px rgba(0,0,0,0.35)",
            transition: dragging ? undefined : "left 280ms cubic-bezier(.2,.8,.2,1)",
            touchAction: "none",
          }}
        >
          <Power
            size={22}
            strokeWidth={2.4}
            className="text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)]"
          />
        </button>
      </div>

      {/* Cancel hint */}
      <p
        className="mt-12 font-sans text-xs text-white/40"
        style={{ opacity: textOpacity * 0.9 }}
      >
        Cancel
      </p>
    </div>
  )
}
